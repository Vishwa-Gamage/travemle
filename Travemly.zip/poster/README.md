# Travemle Research Poster

## Files
- `travemle_poster.tex` — Main LaTeX poster source
- `travemle.bib`        — Bibliography references
- `figures/`           — Place all images here

---

## How to Compile

### Option 1: Overleaf (Recommended — No installation needed)
1. Go to [overleaf.com](https://www.overleaf.com) → New Project → Upload ZIP
2. Zip this entire `poster/` folder and upload it
3. Set compiler to **pdfLaTeX**
4. Upload your figures to the `figures/` folder in Overleaf
5. Click **Compile**

### Option 2: Local (MiKTeX / TeX Live)
```bash
pdflatex travemle_poster.tex
bibtex travemle_poster
pdflatex travemle_poster.tex
pdflatex travemle_poster.tex
```

---

## Required Figures (place in `figures/` folder)

| Filename | Description | Suggested Tool |
|----------|-------------|----------------|
| `SLTC LOGO.png` | SLTC University logo | From university website |
| `system_architecture.png` | Client → API → Groq/OWM/DB diagram | draw.io / Lucidchart |
| `intelligence_pipeline.png` | 9-step pipeline flowchart | draw.io |
| `api_response_breakdown.png` | Bar chart of pipeline step timings | Excel / Python matplotlib |
| `weather_accuracy.png` | OWM forecast vs observed table/graph | Python / Excel |
| `season_heatmap.png` | 3-region × 12-month heatmap | Python seaborn |
| `budget_tier_distribution.png` | Pie or bar chart of budget tiers | Python / Excel |
| `interest_frequency.png` | Bar chart of interest tag frequencies | Python / Excel |
| `rainy_alert_regions.png` | Trigger rate per month | Python matplotlib |
| `app_screens.png` | Screenshots of the Expo app | Android/iOS screenshot composite |

---

## Things to Update Before Submission

1. **Student IDs** — Replace `22UG1-XXXX` with actual IDs in the `\huge\textbf{...}` line
2. **Author names** — Confirm spelling of both authors
3. **Department name** — Confirm exact department name at SLTC
4. **Email** — Replace `travemle@sltc.ac.lk` with actual contact email
5. **Supervisor names** — Confirm Miss/Mr title and spelling
6. **Figures** — Generate and place all figures listed above in `figures/`
7. **SLTC Logo** — Copy from your existing project files (already exists at `TravemleApp/assets/`)
